<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
 <!DOCTYPE html>
<html>
  <head>
    <title>MARKS SHEET USING HTML TABLES</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="Keywords" content="html, css, html tables, table">
    <meta name="Description" content="html table">

    <link rel="icon" href="/favicon.ico" type="image/x-icon">
        <link href='http://fonts.googleapis.com/css?family=Lato:400,700' rel='stylesheet' type='text/css'>

   </head>

  <body>
  <style>
    body {
  background-color: #c5cae9;
  padding: 25px;
}

.container {
  width: 800px;
  height: 440px;
  margin: 0 auto;
  padding-left: 32px;
  padding-right: 32px;
  padding-top: 40px;
  border-radius: 12px;
  background-color: #90a4ae;
  font-family: Lato;
}

.container h2 {
  text-align: center;
}

table {
  margin: 0 auto;
}

td,
th {
  padding: 12px;
  border: 2px dotted;
}
   </style>
<?php 
	$con = mysqli_connect("localhost","root","","marksheet");

	if(isset($_POST['submit'])){


$rollno = $_POST['rollno'];
$name = $_POST['name'];
$engmarks= $_POST['engmarks'];
$matmarks = $_POST['matmarks'];
$scimarks = $_POST['scimarks'];
$compscimarks = $_POST['compscimarks'];
$sstmarks = $_POST['sstmarks'];
$totalmarks = $_POST['totalmarks'];
$maxmarks = $_POST['maxmarks'];
$grade = $_POST['grade'];






$query = "INSERT INTO `marks`(`rollno`, `name`, `engmarks`, `matmarks`, `scimarks`, `compscimarks`, `sstmarks`, `totalmarks`, `maxmarks`, `grade`) VALUES ('$rollno' , '$name' , '$engmarks', '$matmarks' , '$scimarks', '$compscimarks', '$sstmarks', '$totalmarks', '$maxmarks', '$grade')";

$run = mysqli_query($con , $query);




 
 
	}
    else{
        echo "<script>
        alert();
        
        </script>";
    }
    
    
     

	
	?>


    <div class="container">
      <h2>MARKSHEET</h2>
  
      <table>
        <thead>
          <tr>
            <th>Roll No.</th>
            <th>Name</th>
            <th>English</th>
            <th>Maths</th>
            <th>Science</th>
            <th>Computer Science</th>
            <th>Social Studies</th>
            <th>Total</th>
            <th>Max Marks</th>
            <th>Grade </th>
            
          <tr>  
            
        </thead>
        <tbody>


          
                    <?php


$con = mysqli_connect("localhost","root","","marksheet");
$query2 = "SELECT * FROM `marks` WHERE 1";
$run2  = mysqli_query($con , $query2);





?>
        <?php
while($row = mysqli_fetch_assoc($run2)){
	?><tr>
            <td><?php echo $row ['rollno'] ?></td>
            <td><?php echo $row ['name'] ?></td>
            <td><?php echo $row ['engmarks'] ?></td>
            <td><?php echo $row ['matmarks'] ?></td>
            <td><?php echo $row ['scimarks'] ?></td>
            <td><?php echo $row ['compscimarks'] ?></td>
            <td><?php echo $row ['sstmarks'] ?></td>
            <td><?php echo $row ['totalmarks'] ?></td>
			<td><?php echo $row ['maxmarks'] ?></td>
      <td><?php echo $row ['grade'] ?></td>
</tr>
     
  

  </body>
  <?php
}

?>
   </tbody>    
      </table>
      </div>
</html>   
</body>
</html>