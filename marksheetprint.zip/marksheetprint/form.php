<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>



<form action="index.php" method="post" enctype="multipart/form-data">
    
<label>ROLL NO</label><input type="text" name="rollno" ><br><br>
    
<label>NAME</label><input type="text" name="name"><br><br>
    
<label>ENG MARKS</label><input type="text" name="engmarks"><br><br>
<label>MATH MARKS</label><input type="text" name="matmarks"><br><br>

<label>SCI MARKS</label><input type="text" name="scimarks"><br><br>
<label>COMPUTER MARKS</label><input type="text" name="compscimarks"><br><br>
<label>SST MARKS</label><input type="text" name="sstmarks"><br><br>
<label>TOTAL MARKS</label><input type="text" name="totalmarks"><br><br>
<label>MAX MARKS</label><input type="text" name="maxmarks"><br><br>
<label>GRADE</label><input type="text" name="grade"><br><br>
<button name="submit" value="Submit">Submit</button>
</form>   
</body>
</html>